package ram;

public class Paul {
	protected void diaplay() {
		System.out.println("hey hello");
	}
}
