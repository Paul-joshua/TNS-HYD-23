package Public;

public class classB {

	public static void main(String[] args) {
		classA a1 = new classA();
		a1.display();
	}

}
