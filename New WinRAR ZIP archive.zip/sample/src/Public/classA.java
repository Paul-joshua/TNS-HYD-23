package Public;

public class classA {
	public void display() {
		System.out.println("paul sermons");
	}
}
