package PRIVATE;

public class B {
	private void display() {
		System.out.println("this is private class");
	}

	public static void main(String[] args) {
		B obj = new B();
		obj.display();
	}

}
