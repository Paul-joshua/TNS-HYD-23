package gettersetter;

public class employee {
    String name;
    double attendance;
    double salary;

    public employee(String name, double attendance, double salary) {
        this.name = name;
        this.attendance = attendance;
        this.salary = salary;
    }

    public static void main(String[] args) {
        employee employee1 = new employee("John Doe", 90.5, 50000.0);
        System.out.println("Employee Name: " + employee1.name);
        System.out.println("Employee Attendance: " + employee1.attendance + "%");
        System.out.println("Employee Salary: $" + employee1.salary);
    }
}