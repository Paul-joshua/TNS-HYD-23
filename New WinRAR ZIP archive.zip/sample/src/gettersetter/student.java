package gettersetter;

public class student {
	
	
	    private String name;
	    private int marks;
	    private double attendance;

	    public student(String name, int marks, double attendance) {
	        this.name = name;
	        this.marks = marks;
	        this.attendance = attendance;
	    }

	    public String getName() {
	        return name;
	    }

	    public void setName(String name) {
	        this.name = name;
	    }

	    public int getMarks() {
	        return marks;
	    }

	    public void setMarks(int marks) {
	        this.marks = marks;
	    }

	    public double getAttendance() {
	        return attendance;
	    }

	    public void setAttendance(double attendance) {
	        this.attendance = attendance;
	    }

	    public static void main(String[] args) {
	        // Create a new Student object
	    	student student1 = new student("paul joshua", 85, 90.5);

	        // Print the student's details
	        System.out.println("Student Name: " + student1.getName());
	        System.out.println("Student Marks: " + student1.getMarks());
	        System.out.println("Student Attendance: " + student1.getAttendance() + "%");

	        // Update the student's marks and attendance
	        student1.setMarks(90);
	        student1.setAttendance(95.0);

	        // Print the updated student's details
	        System.out.println("Updated Student Name: " + student1.getName());
	        System.out.println("Updated Student Marks: " + student1.getMarks());
	        System.out.println("Updated Student Attendance: " + student1.getAttendance() + "%");
	    }
}
	