package com.day1;

public class ClassA {
	int a = 30;// instantaneous variables
	static int b = 20;// static variable

	public static void main(String[] args) {
		int c = 40;
		System.out.println(c);
		ClassA a1 = new ClassA();
		System.out.println(a1.a);
		System.out.println(ClassA.b);

	}
}