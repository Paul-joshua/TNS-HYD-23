package com.day1;

public class ClassB {
	int a = 20;
	static int b = 30;
}
