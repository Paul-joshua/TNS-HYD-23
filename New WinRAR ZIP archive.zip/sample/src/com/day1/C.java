package com.day1;

public class C {
	int c = 40;

	public static void main(String[] args) {
		C c1 = new C();
		System.out.println(c1.c);
		ClassB b1 = new ClassB();
		System.out.println(b1.b);
		System.out.println(ClassB.b);

	}
}
