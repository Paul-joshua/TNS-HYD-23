package defaultp1;

public class A {
	void display() {
		System.out.println("tns class 12-08-24");
	}
}
