package ram2;

import ram.Paul;

public class Paul2 extends Paul {
	public static void main(String[] args) {
		Paul2 a = new Paul2();
		a.diaplay();
	}
}
